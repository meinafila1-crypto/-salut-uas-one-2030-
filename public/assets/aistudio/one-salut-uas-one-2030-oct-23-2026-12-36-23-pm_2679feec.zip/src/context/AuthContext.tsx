import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';

const BOOTSTRAP_ADMIN_EMAIL = 'sn4452869@gmail.com';
const PRIMARY_ADMIN_EMAIL = 'aputchoir456@gmail.com';
const BOOTSTRAP_ADMIN_EMAILS = [BOOTSTRAP_ADMIN_EMAIL, PRIMARY_ADMIN_EMAIL];

interface AuthContextType {
  currentUser: User | null;
  isAdmin: boolean;
  isLoading: boolean;
  adminEmail: string | null;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  isAdmin: false,
  isLoading: true,
  adminEmail: null,
  loginWithGoogle: async () => {},
  logout: async () => {}
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user && user.email) {
        const emailMatches = BOOTSTRAP_ADMIN_EMAILS.some(e => e.toLowerCase() === user.email?.toLowerCase());
        if (emailMatches) {
          setIsAdmin(true);
          try {
            await setDoc(doc(db, 'admins', user.uid), {
              email: user.email,
              role: 'superadmin',
              updatedAt: new Date().toISOString()
            }, { merge: true });
          } catch (e) {
            console.warn('Admin record sync notice:', e);
          }
        } else {
          // Check Firestore admins collection for server-granted permissions
          try {
            const adminDoc = await getDoc(doc(db, 'admins', user.uid));
            setIsAdmin(adminDoc.exists());
          } catch {
            setIsAdmin(false);
          }
        }
      } else {
        setIsAdmin(false);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      if (user.email) {
        const isMaster = BOOTSTRAP_ADMIN_EMAILS.some(e => e.toLowerCase() === user.email?.toLowerCase());
        if (isMaster) {
          setIsAdmin(true);
          try {
            await setDoc(doc(db, 'admins', user.uid), {
              email: user.email,
              role: 'superadmin',
              updatedAt: new Date().toISOString()
            }, { merge: true });
          } catch (e) {
            console.warn('Admin record sync notice:', e);
          }
        } else {
          const adminDoc = await getDoc(doc(db, 'admins', user.uid));
          if (!adminDoc.exists()) {
            await signOut(auth);
            setIsAdmin(false);
            throw new Error(`Akun Google (${user.email}) belum terdaftar sebagai administrator resmi. Hubungi admin utama (${PRIMARY_ADMIN_EMAIL}).`);
          }
          setIsAdmin(true);
        }
      }
    } catch (err: unknown) {
      console.error('Google Sign-in failed:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsAdmin(false);
    await signOut(auth);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAdmin,
        isLoading,
        adminEmail: currentUser?.email || null,
        loginWithGoogle,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
